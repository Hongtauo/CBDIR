# coding=utf-8
"""
Python Behave skeletons (https://pythonhosted.org/behave/)
"""


def given(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def when(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def then(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def step(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass
def Given(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def When(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def Then(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass

def Step(pattern):
    """Decorates a function, so that it will become a new step
    definition.
    :param pattern pattern to match, may be regular expression or something else depends on step matcher
    """
    pass